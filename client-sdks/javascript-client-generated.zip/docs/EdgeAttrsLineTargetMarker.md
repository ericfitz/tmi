# TmiClient.EdgeAttrsLineTargetMarker

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Marker type | [optional] 
**size** | **Number** | Marker size in pixels | [optional] 

<a name="NameEnum"></a>
## Enum: NameEnum

* `classic` (value: `"classic"`)
* `block` (value: `"block"`)
* `diamond` (value: `"diamond"`)
* `circle` (value: `"circle"`)

