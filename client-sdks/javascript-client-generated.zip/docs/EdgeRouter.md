# TmiClient.EdgeRouter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
