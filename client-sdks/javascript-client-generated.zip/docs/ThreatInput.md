# TmiClient.ThreatInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
