# TmiClient.NodeAttrsText

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | Label text content | [optional] 
**fontSize** | **Number** | Font size in pixels | [optional] 
**fill** | **String** | Text color | [optional] 
**fontFamily** | **String** | Font family | [optional] 
