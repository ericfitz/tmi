# TmiClient.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuer** | **String** |  | 
**authorizationEndpoint** | **String** |  | 
**tokenEndpoint** | **String** |  | 
**userinfoEndpoint** | **String** |  | [optional] 
**jwksUri** | **String** |  | 
**responseTypesSupported** | **[String]** |  | 
**subjectTypesSupported** | **[String]** |  | 
**idTokenSigningAlgValuesSupported** | **[String]** |  | 
**scopesSupported** | **[String]** |  | [optional] 
**claimsSupported** | **[String]** |  | [optional] 
**introspectionEndpoint** | **String** |  | [optional] 
