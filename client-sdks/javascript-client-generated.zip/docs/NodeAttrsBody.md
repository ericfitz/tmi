# TmiClient.NodeAttrsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fill** | **String** | Fill color | [optional] 
**stroke** | **String** | Stroke color | [optional] 
**strokeWidth** | **Number** | Stroke width in pixels | [optional] 
**strokeDasharray** | **String** | Dash pattern for strokes | [optional] 
