# TmiClient.DfdDiagram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | DFD diagram type with version | [optional] 
**cells** | **[Object]** | List of diagram cells (nodes and edges) following X6 structure | 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `dFD100` (value: `"DFD-1.0.0"`)

