# TmiClient.EdgeAttrsLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**stroke** | **String** | Line color | [optional] 
**strokeWidth** | **Number** | Line width in pixels | [optional] 
**strokeDasharray** | **String** | Dash pattern for the line | [optional] 
**targetMarker** | [**EdgeAttrsLineTargetMarker**](EdgeAttrsLineTargetMarker.md) |  | [optional] 
**sourceMarker** | [**EdgeAttrsLineSourceMarker**](EdgeAttrsLineSourceMarker.md) |  | [optional] 
