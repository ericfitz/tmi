# TmiClient.ThreatModelsThreatModelIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**op** | **String** | Patch operation type | 
**path** | **String** | JSON path to target | 
**value** | **Object** | Value to apply | [optional] 

<a name="OpEnum"></a>
## Enum: OpEnum

* `add` (value: `"add"`)
* `replace` (value: `"replace"`)
* `remove` (value: `"remove"`)
* `move` (value: `"move"`)
* `copy` (value: `"copy"`)
* `test` (value: `"test"`)

