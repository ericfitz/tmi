# TmiClient.DocumentInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
