# TmiClient.PortConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groups** | [**{String: PortConfigurationGroups}**](PortConfigurationGroups.md) | Port group definitions | [optional] 
**items** | [**[PortConfigurationItems]**](PortConfigurationItems.md) | Individual port instances | [optional] 
