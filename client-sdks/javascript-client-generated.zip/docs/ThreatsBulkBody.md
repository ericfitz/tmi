# TmiClient.ThreatsBulkBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**patches** | [**[ThreatModelsthreatModelIdthreatsbulkPatches]**](ThreatModelsthreatModelIdthreatsbulkPatches.md) |  | 
