# TmiClient.DiagramListItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Unique identifier of the diagram (UUID) | 
**name** | **String** | Name of the diagram | 
**type** | **String** | Type of the diagram | 

<a name="TypeEnum"></a>
## Enum: TypeEnum

* `dFD100` (value: `"DFD-1.0.0"`)

