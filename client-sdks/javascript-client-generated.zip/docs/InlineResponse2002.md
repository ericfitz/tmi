# TmiClient.InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**[InlineResponse2002Keys]**](InlineResponse2002Keys.md) |  | 
