# TmiClient.PortConfigurationItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Unique port identifier | 
**group** | **String** | Port group this port belongs to | 
