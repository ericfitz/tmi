# TmiClient.InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuer** | **String** |  | 
**authorizationEndpoint** | **String** |  | 
**tokenEndpoint** | **String** |  | 
**introspectionEndpoint** | **String** |  | [optional] 
**responseTypesSupported** | **[String]** |  | 
**grantTypesSupported** | **[String]** |  | [optional] 
**tokenEndpointAuthMethodsSupported** | **[String]** |  | [optional] 
