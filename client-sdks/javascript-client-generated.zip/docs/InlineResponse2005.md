# TmiClient.InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idp** | **String** | Identity provider ID | 
**groups** | [**[InlineResponse2005Groups]**](InlineResponse2005Groups.md) |  | 
