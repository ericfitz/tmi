# TmiClient.Oauth2IntrospectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **String** | The JWT token to introspect | 
**tokenTypeHint** | **String** | Optional hint about the type of token being introspected | [optional] 
