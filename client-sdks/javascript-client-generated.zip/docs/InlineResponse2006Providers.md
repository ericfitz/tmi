# TmiClient.InlineResponse2006Providers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provider** | **String** | OAuth provider name | [optional] 
**isPrimary** | **Boolean** | Whether this is the primary authentication method | [optional] 
