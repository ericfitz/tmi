# TmiClient.Point

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**x** | **Number** | X coordinate | 
**y** | **Number** | Y coordinate | 
