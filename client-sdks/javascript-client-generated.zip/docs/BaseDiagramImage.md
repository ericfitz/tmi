# TmiClient.BaseDiagramImage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**svg** | **Blob** | BASE64 encoded SVG representation of the diagram, used for thumbnails and reports | [optional] 
**updateVector** | **Number** | Version of the diagram when this SVG was generated. If not provided when svg is updated, will be auto-set to BaseDiagram.update_vector | [optional] 
