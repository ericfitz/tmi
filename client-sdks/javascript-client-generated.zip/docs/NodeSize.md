# TmiClient.NodeSize

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | **Number** | Width in pixels | 
**height** | **Number** | Height in pixels | 
