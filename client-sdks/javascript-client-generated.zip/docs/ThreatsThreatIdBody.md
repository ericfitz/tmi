# TmiClient.ThreatsThreatIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**op** | **String** |  | 
**path** | **String** |  | 
**value** | **Object** |  | [optional] 
**from** | **String** |  | [optional] 

<a name="OpEnum"></a>
## Enum: OpEnum

* `add` (value: `"add"`)
* `remove` (value: `"remove"`)
* `replace` (value: `"replace"`)
* `move` (value: `"move"`)
* `copy` (value: `"copy"`)
* `test` (value: `"test"`)

