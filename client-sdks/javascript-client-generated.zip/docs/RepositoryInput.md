# TmiClient.RepositoryInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
