# TmiClient.AssetInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
