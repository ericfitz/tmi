# TmiClient.DocumentBase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Document name | 
**description** | **String** | Description of document purpose or content | [optional] 
**uri** | **String** | URL location of the document | 
