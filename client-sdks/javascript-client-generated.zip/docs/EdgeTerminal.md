# TmiClient.EdgeTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cell** | **String** | ID of the connected node (UUID) | 
**port** | **String** | ID of the specific port on the node (optional) | [optional] 
