# TmiClient.Oauth2RefreshBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refreshToken** | **String** | Valid refresh token | 
