# TmiClient.InlineResponse2002Keys

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kty** | **String** |  | 
**use** | **String** |  | 
**alg** | **String** |  | 
**kid** | **String** |  | 
