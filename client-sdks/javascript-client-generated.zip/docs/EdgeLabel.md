# TmiClient.EdgeLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attrs** | [**EdgeLabelAttrs**](EdgeLabelAttrs.md) |  | [optional] 
**position** | **Number** | Position along the edge (0 &#x3D; start, 1 &#x3D; end) | [optional] 
