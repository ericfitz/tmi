# TmiClient.ExtendedAsset

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**threatModelId** | **String** | ID of the threat model this asset belongs to | 
**createdAt** | **Date** | Creation timestamp (ISO3339) | 
**modifiedAt** | **Date** | Last modification timestamp (ISO3339) | 
