# TmiClient.ThreatModelsthreatModelIdthreatsbulkPatches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Threat ID to patch | 
**operations** | [**[ThreatsThreatIdBody]**](ThreatsThreatIdBody.md) | JSON Patch operations to apply | 
