# TmiClient.InlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deletedCount** | **Number** | Number of threats deleted | [optional] 
**deletedIds** | **[String]** | IDs of deleted threats | [optional] 
