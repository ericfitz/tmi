# TmiClient.SamlSloBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sAMLRequest** | **String** | Base64-encoded SAML logout request | 
