# TmiClient.PortConfigurationGroups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**position** | **String** | Port position on the node | [optional] 

<a name="PositionEnum"></a>
## Enum: PositionEnum

* `top` (value: `"top"`)
* `right` (value: `"right"`)
* `bottom` (value: `"bottom"`)
* `left` (value: `"left"`)

