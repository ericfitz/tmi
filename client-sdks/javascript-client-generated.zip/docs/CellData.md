# TmiClient.CellData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**metadata** | [**[Metadata]**](Metadata.md) | Reserved namespace for structured business metadata | [optional] 
