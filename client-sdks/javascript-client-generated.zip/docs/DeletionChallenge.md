# TmiClient.DeletionChallenge

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**challengeText** | **String** | The exact challenge string that must be provided to confirm deletion | 
**expiresAt** | **Date** | When the challenge expires (3 minutes from issuance) | 
