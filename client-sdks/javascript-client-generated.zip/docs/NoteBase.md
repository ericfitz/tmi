# TmiClient.NoteBase

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Note name | 
**content** | **String** | Note content in markdown format | 
**description** | **String** | Description of note purpose or context | [optional] 
