# SamlAcsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**saMLResponse** | **String** | Base64-encoded SAML response | 
**relayState** | **String** | State parameter for CSRF protection |  [optional]
