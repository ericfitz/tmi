# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**providers** | [**List&lt;InlineResponse2004Providers&gt;**](InlineResponse2004Providers.md) |  | 
