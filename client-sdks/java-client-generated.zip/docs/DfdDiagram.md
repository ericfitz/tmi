# DfdDiagram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cells** | **List&lt;Object&gt;** | List of diagram cells (nodes and edges) following X6 structure | 
