# ThreatsBulkBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**patches** | [**List&lt;ThreatModelsthreatModelIdthreatsbulkPatches&gt;**](ThreatModelsthreatModelIdthreatsbulkPatches.md) |  | 
