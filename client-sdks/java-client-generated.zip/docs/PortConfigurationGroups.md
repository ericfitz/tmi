# PortConfigurationGroups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**position** | [**PositionEnum**](#PositionEnum) | Port position on the node |  [optional]

<a name="PositionEnum"></a>
## Enum: PositionEnum
Name | Value
---- | -----
TOP | &quot;top&quot;
RIGHT | &quot;right&quot;
BOTTOM | &quot;bottom&quot;
LEFT | &quot;left&quot;
