# ApiInfoOperator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Operator name from environment variables | 
**contact** | **String** | Operator contact information from environment variables | 
