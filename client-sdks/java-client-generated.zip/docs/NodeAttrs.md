# NodeAttrs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**NodeAttrsBody**](NodeAttrsBody.md) |  |  [optional]
**text** | [**NodeAttrsText**](NodeAttrsText.md) |  |  [optional]
