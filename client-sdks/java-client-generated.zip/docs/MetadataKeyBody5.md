# MetadataKeyBody5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **String** | New value for the metadata entry | 
