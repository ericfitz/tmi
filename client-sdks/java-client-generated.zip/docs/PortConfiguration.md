# PortConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groups** | [**Map&lt;String, PortConfigurationGroups&gt;**](PortConfigurationGroups.md) | Port group definitions |  [optional]
**items** | [**List&lt;PortConfigurationItems&gt;**](PortConfigurationItems.md) | Individual port instances |  [optional]
