# InlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deletedCount** | **Integer** | Number of threats deleted |  [optional]
**deletedIds** | [**List&lt;UUID&gt;**](UUID.md) | IDs of deleted threats |  [optional]
