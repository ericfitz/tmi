# DocumentInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
