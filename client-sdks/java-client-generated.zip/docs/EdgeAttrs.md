# EdgeAttrs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line** | [**EdgeAttrsLine**](EdgeAttrsLine.md) |  |  [optional]
