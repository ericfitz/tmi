# EdgeAttrsLineTargetMarker

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**NameEnum**](#NameEnum) | Marker type |  [optional]
**size** | [**BigDecimal**](BigDecimal.md) | Marker size in pixels |  [optional]

<a name="NameEnum"></a>
## Enum: NameEnum
Name | Value
---- | -----
CLASSIC | &quot;classic&quot;
BLOCK | &quot;block&quot;
DIAMOND | &quot;diamond&quot;
CIRCLE | &quot;circle&quot;
