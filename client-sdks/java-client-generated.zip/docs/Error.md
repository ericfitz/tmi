# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Error code | 
**errorDescription** | **String** | Human-readable error description | 
**errorUri** | **String** | URI to documentation about the error |  [optional]
**details** | [**ErrorDetails**](ErrorDetails.md) |  |  [optional]
