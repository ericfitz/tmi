# CellTool

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Tool identifier (e.g., &#x27;boundary&#x27;, &#x27;button&#x27;, &#x27;remove&#x27;) | 
**args** | **Map&lt;String, Object&gt;** | Tool-specific configuration arguments |  [optional]
