# SamlSloBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**saMLRequest** | **String** | Base64-encoded SAML logout request | 
