# CreateDiagramRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the diagram | 
**type** | [**TypeEnum**](#TypeEnum) | Type of diagram with version | 

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
DFD_1_0_0 | &quot;DFD-1.0.0&quot;
