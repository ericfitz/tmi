# Diagram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
