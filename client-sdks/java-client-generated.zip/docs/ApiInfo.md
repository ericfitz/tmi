# ApiInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | [**ApiInfoStatus**](ApiInfoStatus.md) |  | 
**service** | [**ApiInfoService**](ApiInfoService.md) |  | 
**api** | [**ApiInfoApi**](ApiInfoApi.md) |  | 
**operator** | [**ApiInfoOperator**](ApiInfoOperator.md) |  | 
