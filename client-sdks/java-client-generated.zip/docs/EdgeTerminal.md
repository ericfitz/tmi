# EdgeTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cell** | [**UUID**](UUID.md) | ID of the connected node (UUID) | 
**port** | **String** | ID of the specific port on the node (optional) |  [optional]
