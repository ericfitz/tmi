# ThreatsThreatIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**op** | [**OpEnum**](#OpEnum) |  | 
**path** | **String** |  | 
**value** | **Object** |  |  [optional]
**from** | **String** |  |  [optional]

<a name="OpEnum"></a>
## Enum: OpEnum
Name | Value
---- | -----
ADD | &quot;add&quot;
REMOVE | &quot;remove&quot;
REPLACE | &quot;replace&quot;
MOVE | &quot;move&quot;
COPY | &quot;copy&quot;
TEST | &quot;test&quot;
