# ThreatModelsthreatModelIdthreatsbulkPatches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**UUID**](UUID.md) | Threat ID to patch | 
**operations** | [**List&lt;ThreatsThreatIdBody&gt;**](ThreatsThreatIdBody.md) | JSON Patch operations to apply | 
