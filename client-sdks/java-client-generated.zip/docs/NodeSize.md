# NodeSize

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**width** | [**BigDecimal**](BigDecimal.md) | Width in pixels | 
**height** | [**BigDecimal**](BigDecimal.md) | Height in pixels | 
