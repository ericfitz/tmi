# EdgeLabelAttrsText

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** | Label text content |  [optional]
**fontSize** | [**BigDecimal**](BigDecimal.md) | Font size in pixels |  [optional]
**fill** | **String** | Text color |  [optional]
**fontFamily** | **String** | Font family |  [optional]
