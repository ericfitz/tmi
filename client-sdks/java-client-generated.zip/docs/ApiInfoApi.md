# ApiInfoApi

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** | API version | 
**specification** | **String** | URL to the API specification | 
