# Metadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Metadata key | 
**value** | **String** | Metadata value | 
