# Point

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**x** | [**BigDecimal**](BigDecimal.md) | X coordinate | 
**y** | [**BigDecimal**](BigDecimal.md) | Y coordinate | 
