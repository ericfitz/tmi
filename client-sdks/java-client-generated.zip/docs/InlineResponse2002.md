# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**keys** | [**List&lt;InlineResponse2002Keys&gt;**](InlineResponse2002Keys.md) |  | 
