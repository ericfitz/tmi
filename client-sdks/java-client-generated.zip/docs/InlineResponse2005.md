# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idp** | **String** | Identity provider ID | 
**groups** | [**List&lt;InlineResponse2005Groups&gt;**](InlineResponse2005Groups.md) |  | 
