# InlineResponse2005Groups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Group name | 
**displayName** | **String** | Display name for the group |  [optional]
**usedInAuthorizations** | **Boolean** | Whether this group is used in any threat model authorizations |  [optional]
