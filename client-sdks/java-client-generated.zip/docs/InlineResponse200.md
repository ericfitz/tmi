# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuer** | **String** |  | 
**authorizationEndpoint** | **String** |  | 
**tokenEndpoint** | **String** |  | 
**userinfoEndpoint** | **String** |  |  [optional]
**jwksUri** | **String** |  | 
**responseTypesSupported** | **List&lt;String&gt;** |  | 
**subjectTypesSupported** | **List&lt;String&gt;** |  | 
**idTokenSigningAlgValuesSupported** | **List&lt;String&gt;** |  | 
**scopesSupported** | **List&lt;String&gt;** |  |  [optional]
**claimsSupported** | **List&lt;String&gt;** |  |  [optional]
**introspectionEndpoint** | **String** |  |  [optional]
