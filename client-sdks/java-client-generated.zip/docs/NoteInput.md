# NoteInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
