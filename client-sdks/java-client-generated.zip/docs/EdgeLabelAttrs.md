# EdgeLabelAttrs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | [**EdgeLabelAttrsText**](EdgeLabelAttrsText.md) |  |  [optional]
