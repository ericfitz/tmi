# InlineResponse409

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | **String** | Error message indicating session already exists | 
**joinUrl** | **String** | URL to join the existing collaboration session | 
