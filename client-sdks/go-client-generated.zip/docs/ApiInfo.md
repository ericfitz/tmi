# ApiInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Status** | [***ApiInfoStatus**](ApiInfo_status.md) |  | [default to null]
**Service** | [***ApiInfoService**](ApiInfo_service.md) |  | [default to null]
**Api** | [***ApiInfoApi**](ApiInfo_api.md) |  | [default to null]
**Operator** | [***ApiInfoOperator**](ApiInfo_operator.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

