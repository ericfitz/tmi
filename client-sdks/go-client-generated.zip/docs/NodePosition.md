# NodePosition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**X** | **float64** | X coordinate | [default to null]
**Y** | **float64** | Y coordinate | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

