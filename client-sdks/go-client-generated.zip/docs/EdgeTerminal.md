# EdgeTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cell** | **string** | ID of the connected node (UUID) | [default to null]
**Port** | **string** | ID of the specific port on the node (optional) | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

