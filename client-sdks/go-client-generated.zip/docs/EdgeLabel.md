# EdgeLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Attrs** | [***EdgeLabelAttrs**](EdgeLabel_attrs.md) |  | [optional] [default to null]
**Position** | **float64** | Position along the edge (0 &#x3D; start, 1 &#x3D; end) | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

