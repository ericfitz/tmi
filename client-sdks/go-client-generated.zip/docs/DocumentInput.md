# DocumentInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Document name | [default to null]
**Description** | **string** | Description of document purpose or content | [optional] [default to null]
**Uri** | **string** | URL location of the document | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

