# InlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeletedCount** | **int32** | Number of threats deleted | [optional] [default to null]
**DeletedIds** | **[]string** | IDs of deleted threats | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

