# NodeAttrs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Body** | [***NodeAttrsBody**](NodeAttrs_body.md) |  | [optional] [default to null]
**Text** | [***NodeAttrsText**](NodeAttrs_text.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

