# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Issuer** | **string** |  | [default to null]
**AuthorizationEndpoint** | **string** |  | [default to null]
**TokenEndpoint** | **string** |  | [default to null]
**IntrospectionEndpoint** | **string** |  | [optional] [default to null]
**ResponseTypesSupported** | **[]string** |  | [default to null]
**GrantTypesSupported** | **[]string** |  | [optional] [default to null]
**TokenEndpointAuthMethodsSupported** | **[]string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

