# Participant

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**User** | [***User**](User.md) |  | [default to null]
**LastActivity** | [**time.Time**](time.Time.md) | Last activity timestamp | [default to null]
**Permissions** | **string** | Access permissions in the collaboration session | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

