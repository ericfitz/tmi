# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Idp** | **string** | Identity provider ID | [default to null]
**Groups** | [**[]InlineResponse2005Groups**](inline_response_200_5_groups.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

