# NodeAttrsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Fill** | **string** | Fill color | [optional] [default to null]
**Stroke** | **string** | Stroke color | [optional] [default to null]
**StrokeWidth** | **float64** | Stroke width in pixels | [optional] [default to null]
**StrokeDasharray** | **string** | Dash pattern for strokes | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

