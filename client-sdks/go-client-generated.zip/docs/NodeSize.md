# NodeSize

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Width** | **float64** | Width in pixels | [default to null]
**Height** | **float64** | Height in pixels | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

