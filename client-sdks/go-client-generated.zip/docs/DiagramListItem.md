# DiagramListItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Unique identifier of the diagram (UUID) | [default to null]
**Name** | **string** | Name of the diagram | [default to null]
**Type_** | **string** | Type of the diagram | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

