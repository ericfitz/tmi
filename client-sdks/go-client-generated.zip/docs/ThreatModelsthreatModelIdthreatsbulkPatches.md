# ThreatModelsthreatModelIdthreatsbulkPatches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Threat ID to patch | [default to null]
**Operations** | [**[]ThreatsThreatIdBody**](threats_threat_id_body.md) | JSON Patch operations to apply | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

