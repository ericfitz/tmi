# InlineResponse2005Groups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Group name | [default to null]
**DisplayName** | **string** | Display name for the group | [optional] [default to null]
**UsedInAuthorizations** | **bool** | Whether this group is used in any threat model authorizations | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

