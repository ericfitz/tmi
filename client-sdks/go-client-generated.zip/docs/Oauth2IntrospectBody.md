# Oauth2IntrospectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Token** | **string** | The JWT token to introspect | [default to null]
**TokenTypeHint** | **string** | Optional hint about the type of token being introspected | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

