# ThreatsThreatIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Op** | **string** |  | [default to null]
**Path** | **string** |  | [default to null]
**Value** | [***Object**](.md) |  | [optional] [default to null]
**From** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

