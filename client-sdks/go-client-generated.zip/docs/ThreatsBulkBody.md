# ThreatsBulkBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Patches** | [**[]ThreatModelsthreatModelIdthreatsbulkPatches**](threat_modelsthreat_model_idthreatsbulk_patches.md) |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

