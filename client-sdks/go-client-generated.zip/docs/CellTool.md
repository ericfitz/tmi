# CellTool

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Tool identifier (e.g., &#x27;boundary&#x27;, &#x27;button&#x27;, &#x27;remove&#x27;) | [default to null]
**Args** | [**ModelMap**](interface{}.md) | Tool-specific configuration arguments | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

