# InlineResponse2002Keys

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Kty** | **string** |  | [default to null]
**Use** | **string** |  | [default to null]
**Alg** | **string** |  | [default to null]
**Kid** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

