# Oauth2IntrospectBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**token** | **str** | The JWT token to introspect | 
**token_type_hint** | **str** | Optional hint about the type of token being introspected | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

