# CellTool

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Tool identifier (e.g., &#x27;boundary&#x27;, &#x27;button&#x27;, &#x27;remove&#x27;) | 
**args** | **dict(str, object)** | Tool-specific configuration arguments | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

