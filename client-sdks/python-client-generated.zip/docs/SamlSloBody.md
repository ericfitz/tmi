# SamlSloBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**saml_request** | **str** | Base64-encoded SAML logout request | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

