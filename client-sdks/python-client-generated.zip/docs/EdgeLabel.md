# EdgeLabel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attrs** | [**EdgeLabelAttrs**](EdgeLabelAttrs.md) |  | [optional] 
**position** | **float** | Position along the edge (0 &#x3D; start, 1 &#x3D; end) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

