# SamlAcsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**saml_response** | **str** | Base64-encoded SAML response | 
**relay_state** | **str** | State parameter for CSRF protection | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

