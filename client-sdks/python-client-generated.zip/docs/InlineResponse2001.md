# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuer** | **str** |  | 
**authorization_endpoint** | **str** |  | 
**token_endpoint** | **str** |  | 
**introspection_endpoint** | **str** |  | [optional] 
**response_types_supported** | **list[str]** |  | 
**grant_types_supported** | **list[str]** |  | [optional] 
**token_endpoint_auth_methods_supported** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

