# EdgeTerminal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cell** | **str** | ID of the connected node (UUID) | 
**port** | **str** | ID of the specific port on the node (optional) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

