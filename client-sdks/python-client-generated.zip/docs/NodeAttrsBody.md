# NodeAttrsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fill** | **str** | Fill color | [optional] 
**stroke** | **str** | Stroke color | [optional] 
**stroke_width** | **float** | Stroke width in pixels | [optional] 
**stroke_dasharray** | **str** | Dash pattern for strokes | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

