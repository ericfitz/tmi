# DfdDiagram

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | DFD diagram type with version | [optional] 
**cells** | **list[object]** | List of diagram cells (nodes and edges) following X6 structure | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

