# NodeAttrsText

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **str** | Label text content | [optional] 
**font_size** | **float** | Font size in pixels | [optional] 
**fill** | **str** | Text color | [optional] 
**font_family** | **str** | Font family | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

