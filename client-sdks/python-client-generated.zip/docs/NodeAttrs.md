# NodeAttrs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**NodeAttrsBody**](NodeAttrsBody.md) |  | [optional] 
**text** | [**NodeAttrsText**](NodeAttrsText.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

