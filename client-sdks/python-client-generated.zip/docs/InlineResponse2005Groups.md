# InlineResponse2005Groups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Group name | 
**display_name** | **str** | Display name for the group | [optional] 
**used_in_authorizations** | **bool** | Whether this group is used in any threat model authorizations | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

