# DeletionChallenge

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**challenge_text** | **str** | The exact challenge string that must be provided to confirm deletion | 
**expires_at** | **datetime** | When the challenge expires (3 minutes from issuance) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

