# PortConfigurationGroups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**position** | **str** | Port position on the node | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

