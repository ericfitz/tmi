# EdgeConnectorArgs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**radius** | **float** | Radius for rounded connectors | [optional] 
**precision** | **float** | Precision for smooth connectors | [optional] 
**size** | **float** | Jump size for jumpover connectors | [optional] 
**jump** | **str** | Jump style for jumpover connectors | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

