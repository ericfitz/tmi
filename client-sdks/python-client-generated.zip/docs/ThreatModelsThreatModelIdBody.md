# ThreatModelsThreatModelIdBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**op** | **str** | Patch operation type | 
**path** | **str** | JSON path to target | 
**value** | **object** | Value to apply | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

