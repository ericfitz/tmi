# PortConfiguration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groups** | [**dict(str, PortConfigurationGroups)**](PortConfigurationGroups.md) | Port group definitions | [optional] 
**items** | [**list[PortConfigurationItems]**](PortConfigurationItems.md) | Individual port instances | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

