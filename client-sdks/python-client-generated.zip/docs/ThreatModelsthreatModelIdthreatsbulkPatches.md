# ThreatModelsthreatModelIdthreatsbulkPatches

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Threat ID to patch | 
**operations** | [**list[ThreatsThreatIdBody]**](ThreatsThreatIdBody.md) | JSON Patch operations to apply | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

