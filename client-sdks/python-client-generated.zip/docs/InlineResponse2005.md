# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idp** | **str** | Identity provider ID | 
**groups** | [**list[InlineResponse2005Groups]**](InlineResponse2005Groups.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

