# ApiInfoStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | Status code indicating if the API is functioning correctly | 
**time** | **datetime** | Current server time in UTC, formatted as RFC 3339 | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

